<?php
include_once 'Data/Data.php';
include_once 'lib/nusoap.php';
$servicio = new soap_server();

$ns = "urn:miserviciowsdl";
$servicio->configureWSDL("MiPrimerServicioWeb",$ns);
$servicio->schemaTargetNamespace = $ns;

$servicio->register("MiFuncion", array('nombre' => 'xsd:string','numero_cuenta' => 'xsd:integer'
		,'csc' => 'xsd:integer','monto' => 'xsd:integer','nombre_negocio' => 'xsd:string','numero_factura' => 'xsd:integer','fecha' => 'xsd:string','email' => 'xsd:string'),array('return' => 'xsd:boolean'),$ns );

function MiFuncion($nombre, $numero_cuenta,$csc,$monto,$nombre_negocio,$numero_factura,$fecha,$email){
	/*$conn = new mysqli($this->server, $this->user, $this->password, $this->db);
    $conn->set_charset('utf8');
    $query = "select * from tbaccount where numberCard=$numero_factura and CSC=$csc";
 	$data=mysqli_fetch_all($query);
 	$done=false;
 	foreach ($data as $current) {
 			$id=$current[5];
			$query2 = "select *from tbclient where idClient=$id";	
			$data2=mysqli_fetch_all($query2);
			if (sizeof($data2) >= 1) {
				$done=true;
			}
			else{
				$done=false;
			}
	}	
	return $done;*/
	return true;
								

}

$HTTP_RAW_POST_DATA = isset($HTTP_RAW_POST_DATA) ? $HTTP_RAW_POST_DATA : '';
$servicio->service($HTTP_RAW_POST_DATA);


?>
